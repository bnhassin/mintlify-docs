# BnhassinAgent deployment setup

This implements the blueprint:

GitHub -> CI -> Vercel Preview/Production -> MCP/Agent

## 1. Repository prerequisites

The blueprint requires these paths/files before CI is considered final:

- `agent/`
- `tests/`
- `requirements.txt`
- a Vercel-compatible deployment entrypoint

The workflows in this package assume `pytest` is available from `requirements.txt`.

## 2. GitHub secrets

Create these repository/environment secrets:

- `VERCEL_TOKEN`
- `VERCEL_ORG_ID`
- `VERCEL_PROJECT_ID`

Recommended environments:

- `preview` for pull-request deployments
- `production` for pushes to `main`

Do not commit API keys.

## 3. Vercel

The workflows intentionally use GitHub Actions for Vercel deployment. Do not also enable Vercel's native Git deployment for the same project, otherwise each change can produce duplicate deployments.

`vercel.json` is intentionally minimal because the blueprint does not define the actual MCP/agent runtime or deployment entrypoint.

## 4. Production health check

The production health check is left commented out until the real endpoint is defined.

When the endpoint is known, replace `/health` in:

    curl --fail --show-error --silent "$DEPLOYMENT_URL/health"

with the actual path, and uncomment the step.

## 5. Mintlify

If `docs.json` exists, CI runs:

- validate
- broken-links
- a11y

The workflow skips these commands when the documentation prerequisite is not present.

## 6. Branch protection

Configure `main` to require:

- pull requests
- at least one review
- required status checks

The exact check names should match the required GitHub Actions jobs after the first successful run.
